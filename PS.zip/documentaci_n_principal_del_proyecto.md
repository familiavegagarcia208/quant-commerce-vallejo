# 👟 Quant-Commerce: Zapatería Vallejo

Sistema automatizado de ingeniería de datos, auditoría de inventario en tiempo real, análisis financiero (*Unit Economics*) y estudio fotográfico HD para comercio electrónico, diseñado específicamente para operar con el inventario físico de **Sucursal Vallejo** (Price Shoes $\rightarrow$ Mercado Libre).

---

## 🎯 Objetivo del Sistema

El pipeline opera bajo una **política estricta de inventario curado**: procesa, audita y publica **exclusivamente los productos pertenecientes a los 44 Catálogos PDF Oficiales**, descartando automáticamente cualquier residuo externo de sitemaps generales web.

1. **Extracción Oficial:** Identifica los SKUs directamente desde los 44 catálogos PDF oficiales (`origen_catalogo`).
2. **Auditoría Anti-Ban Inteligente:** Prioriza qué productos escanear mediante un modelo **UCB (Upper Confidence Bound) Bayesiano**, extrayendo costo de socio real y disponibilidad exacta por talla en la fila de **Sucursal Vallejo** (tanto calzado en numeración decimal como ropa, lencería, calcetería y jeans).
3. **Estudio Fotográfico Automatizado ($1200 \times 1200\text{ px}$):** Genera un carrusel comercial de 4 láminas HD en relación $1:1$ sin rotación ($0^\circ$), aplicando un clasificador jerárquico de **12 categorías de prenda**.
4. **Motor Financiero y Semáforo:** Calcula el precio sugerido, descuenta comisiones de Mercado Libre, impuestos ($\text{IVA} + \text{ISR}$) y costos de envío para dictaminar qué modelos son rentables y seguros de publicar.
5. **Panel de Control e Integración:** Permite auditar visualmente todo el catálogo en **Streamlit** y sincronizar las publicaciones aprobadas con Mercado Libre.

---

## 🏗️ Arquitectura del Pipeline

```mermaid
flowchart TD
    classDef source fill:#1e293b,stroke:#f59e0b,stroke-width:2px,color:#fff;
    classDef process fill:#0f172a,stroke:#3b82f6,stroke-width:2px,color:#fff;
    classDef storage fill:#064e3b,stroke:#10b981,stroke-width:2px,color:#fff;
    classDef ui fill:#31102f,stroke:#ec4899,stroke-width:2px,color:#fff;

    subgraph ORIGEN ["1. Fuentes Oficiales"]
        PDF["📘 44 Catálogos PDF Oficiales\n(paso0_extractor_catalogos_pdf.py)"]:::source
        SESION["🔑 Sesión Autenticada\n(paso12_login_socio.py -> sesion_vallejo.json)"]:::source
        WEB["🌐 Portal & CDN Price Shoes\n(Sucursal Vallejo)"]:::source
    end

    subgraph RECOLECCION ["2. Ingesta, Purga y Auditoría Anti-Ban"]
        PURGA["🧹 purgar_fuente_catalogo.py\n(Exclusividad 44 PDFs)"]:::process
        P3["🧠 paso3_recolector_ligero.py\n• Cola Prioritaria + UCB Bayesiano\n• Extracción DOM Playwright\n• Pausas Lognormal Anti-Ban"]:::process
        COMP["🔎 paso3_tracker_competencia.py\n(Monitoreo de mercado)"]:::process
    end

    subgraph PERSISTENCIA ["3. Persistencia Central (Single Source of Truth)"]
        DB[("🗄️ SQLite WAL\ndata/zapateria_vallejo.db\n• zapatos_candidatos\n• historial_stock_21_dias")]:::storage
        FS[("📂 Carruseles HD\ndata/catalogo_listo/{id_ps}/\n• 01_portada_blanca.jpg\n• 02_angulo_galeria.jpg\n• 03_ficha_beneficios.jpg\n• 04_guia_tallas_cm.jpg")]:::storage
    end

    subgraph MOTORES ["4. Procesamiento Financiero, Visual e IA"]
        P5["💰 paso5_motor_financiero.py\npaso5_motor_matematico.py\n• Unit Economics y Comisiones ML\n• Semáforo Recomendado"]:::process
        P6["📸 paso6_estudio_fotografico.py\n• Descarga CDN 2.º Ángulo (0° rot)\n• Clasificador de 12 Categorías\n• Render 1200x1200 px"]:::process
        P7_IA["🤖 paso7_agentes_ia.py\n(Optimización de títulos y fichas)"]:::process
    end

    subgraph SALIDA ["5. Control Operativo, Empaque y Sincronización"]
        P4["📊 paso4_panel_control.py\n(Dashboard Streamlit)"]:::ui
        P8["📦 paso8_poka_yoke_empaque.py\npaso8_preparar_nube.py"]:::process
        ML["🚀 paso7_sincronizador_ml.py\npaso14_sincronizador_real.py\n(Mercado Libre)"]:::source
    end

    PDF --> PURGA --> DB
    SESION --> P3
    WEB <--> P3
    DB <--> P3
    COMP --> DB
    DB <--> P6
    WEB --> P6
    P6 --> FS
    P6 --> P5
    DB <--> P5
    FS --> P5
    DB --> P7_IA
    DB --> P4
    FS --> P4
    P4 --> ML
    ML --> P8
```

---

## 📂 Directorio Completo de Scripts del Proyecto (25 Módulos)

A continuación se documenta cada uno de los archivos `.py` que conforman el repositorio, agrupados por su responsabilidad dentro de la arquitectura:

### ⚙️ 1. Orquestadores Globales y Mantenimiento
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`pipeline_catalogo.py`** | Orquestador maestro que ejecuta en secuencia la auditoría de stock, el cálculo financiero y la generación de carruseles fotográficos para los lotes de los 44 catálogos PDF. |
| **`daemon_vallejo.py`** | Servicio de ejecución continua en segundo plano (*daemon*) encargado de programar micro-sesiones periódicas de escaneo respetando las ventanas de enfriamiento Anti-Ban. |
| **`purgar_fuente_catalogo.py`** | Herramienta de saneamiento estricto que elimina de `zapateria_vallejo.db` y del directorio `data/catalogo_listo/` cualquier SKU o carpeta huérfana que no pertenezca a los 44 catálogos PDF oficiales. |

### 📥 2. Fase 0 a 2: Ingesta, Base de Datos y Radares
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`paso0_extractor_catalogos_pdf.py`** | Analiza los 44 archivos PDF oficiales en `data/catalogos_pdf/`, extrae los códigos de producto (SKUs) y los siembra en SQLite etiquetando su `origen_catalogo` (ej. `1342200 - Caballeros`). |
| **`paso1_crear_bd.py`** | Inicializa el esquema relacional en SQLite (`data/zapateria_vallejo.db`) configurando el modo concurrente `PRAGMA journal_mode=WAL` y creando las tablas base. |
| **`paso2_radar_nivel1.py`** | Escáner de primer nivel para validación rápida de metadatos básicos y disponibilidad general de páginas de producto. |
| **`paso2_radar_sitemap.py`** | *(Módulo de respaldo / legado)* Conector de exploración de sitemaps XML. Desactivado en el flujo principal para garantizar la pureza exclusiva de los 44 catálogos PDF. |

### 🧠 3. Fase 3 y Autenticación: Recolección Anti-Ban y Stock Vallejo
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`paso12_login_socio.py`** | Abre el navegador con Playwright para iniciar sesión con credenciales de socio y guarda las cookies/tokens de autenticación en `data/sesion_vallejo.json`. |
| **`paso3_recolector_ligero.py`** | **Motor principal de recolección.** Filtra exclusivamente los 44 catálogos PDF, ordena la cola por prioridad comercial + algoritmo UCB Bayesiano, abre el modal *"Ver disponibilidad en tiendas"* y extrae el costo de socio y el stock por talla de la fila **Vallejo** (calzado decimal y tallas de ropa/jeans). |
| **`paso3_tracker_competencia.py`** | Rastrea precios de referencia y posicionamiento de productos similares en el mercado para alimentar las decisiones de *pricing*. |
| **`paso13_extraer_stock_vallejo.py`** | Extractor focalizado en la lectura directa de la matriz de inventario de la sucursal Vallejo para validaciones puntuales. |

### 📊 4. Fase 4: Panel de Control e Interfaz Visual (Streamlit)
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`paso4_panel_control.py`** | **Dashboard interactivo en Streamlit.** Incluye selector en barra lateral con los 44 nombres oficiales de catálogo, métricas KPI en vivo, tabla editable con casilla `Subir a ML`, enlaces directos y visor de galería HD de 4 columnas. |
| **`paso4_panel_control_Respaldo.py`** | Copia de seguridad estable de la interfaz de control en Streamlit para recuperación inmediata ante cambios en la UI. |

### 💰 5. Fase 5: Motores Financieros y Matemáticos
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`paso5_motor_financiero.py`** | Calcula los *Unit Economics* de cada SKU: precio de venta sugerido, comisión de categoría en Mercado Libre, retenciones de impuestos ($\text{IVA} / \text{ISR}$), costo de envío, ganancia neta, margen porcentual y **Semáforo de Publicación** (cruzando stock $\ge 5$ y carrusel completo $4/4$). |
| **`paso5_motor_matematico.py`** | Contiene los modelos estadísticos de rotación de inventario, actualización de parámetros bayesianos ($\alpha$, $\beta$), velocidad diaria de venta y clasificación en Tiers ($\text{S}, \text{A}, \text{B}, \text{Z}$). |

### 📸 6. Fase 6: Estudio Fotográfico HD y Clasificador de 12 Categorías
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`paso6_estudio_fotografico.py`** | **Motor gráfico principal ($1200 \times 1200\text{ px}$).** Descarga la 1.ª y 2.ª foto oficial desde el CDN de Price Shoes usando `curl_cffi` ($0^\circ$ de rotación), recorta márgenes blancos, guarda respaldos `_raw.jpg` para evitar sobre-enfoque y genera las 4 láminas comerciales adaptadas a **12 perfiles de prenda**. |
| **`paso6_estudio_pillow.py`** | Biblioteca base de composición gráfica con `Pillow` (fuentes tipográficas, tarjetas de beneficios, chips azules de stock y tablas de equivalencias en centímetros). |

### 🚀 7. Fase 7 y 8: Agentes IA, Nube, Sincronización ML y Poka-Yoke
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`paso7_agentes_ia.py`** | Generación y limpieza inteligente de títulos comerciales SEO, atributos técnicos y descripciones persuasivas para los listados. |
| **`paso7_sincronizador_ml.py`** | Conector de empaquetado de datos y estructura de publicación hacia Mercado Libre. |
| **`paso14_sincronizador_real.py`** | Sincronizador en producción que actualiza existencias y precios reales de los artículos activos para evitar sobreventas (*stockouts*). |
| **`paso8_poka_yoke_empaque.py`** | Sistema de control de calidad a prueba de errores (*Poka-Yoke*) para el proceso de alistamiento y empaque físico de pedidos antes de despachar. |
| **`paso8_preparar_nube.py`** | Empaqueta y optimiza los activos de datos e imágenes para su despliegue o sincronización en entornos cloud. |

### 🧪 8. Fase 10, 11 y 15: Auditoría y Pruebas de Humo
| Archivo | Descripción y Responsabilidad |
| :--- | :--- |
| **`paso10_auditoria_real.py`** | Verifica la integridad referencial entre los registros de `zapateria_vallejo.db`, las tallas en `historial_stock_21_dias` y las 4 láminas físicas en disco. |
| **`paso11_probar_stock_real.py`** | Script de diagnóstico unitario para probar en vivo el raspado del modal de sucursales en un SKU específico. |
| **`paso15_prueba_5_articulos.py`** | Prueba de humo (*smoke test*) ultrarrápida que ejecuta el ciclo completo sobre una muestra de 5 artículos para validar cambios antes de correr lotes masivos. |

---

## 🧮 Modelos Matemáticos y Reglas de Negocio

### 1. Priorización UCB Bayesiana (`paso3_recolector_ligero.py`)
Para maximizar el descubrimiento de stock sin saturar el servidor de origen, el recolector prioriza primero los SKUs vírgenes de los 44 catálogos PDF ($\text{Costo Socio} = 0$) y posteriormente puntúa los SKUs auditados mediante la ecuación *Upper Confidence Bound*:

$$\text{Score}_{\text{UCB}} = \left( \frac{\alpha}{\beta} + 1.41 \frac{\sqrt{\alpha}}{\beta} \right) \cdot \ln\left(1 + \Delta t_{\text{días}}\right)$$

Donde:
* $\alpha$: Parámetro de ventas/salidas acumuladas con factor de decaimiento $\gamma = 0.90$.
* $\beta$: Parámetro de tiempo de exposición acumulado en días.
* $\Delta t_{\text{días}}$: Días transcurridos desde la última sincronización del SKU.
* Las pausas entre peticiones siguen una distribución lognormal acotada en el intervalo $[3.5\text{ s}, 22.0\text{ s}]$.

### 2. Unit Economics y Semáforo Comercial (`paso5_motor_financiero.py`)
La utilidad neta esperada por unidad vendida se modela como:

$$\text{Ganancia Neta} = P_{\text{venta}} - C_{\text{socio}} - \text{Comisión}_{\text{ML}} - \text{Envío} - \text{Retenciones}_{\text{IVA/ISR}}$$

Un artículo recibe el dictamen **✅ RECOMENDADO** únicamente cuando cumple simultáneamente:
1. Pertenece a uno de los **44 Catálogos PDF Oficiales**.
2. Cuenta con las **4 láminas HD ($4/4$)** generadas en `data/catalogo_listo/{id_ps}/`.
3. Tiene stock verificado en Vallejo $\ge 5\text{ unidades}$ y $\text{Ganancia Neta} \ge \$100.00\text{ MXN}$.

---

## 🎨 Estudio Fotográfico HD:Las 4 Láminas y 12 Categorías

El módulo `paso6_estudio_fotografico.py` genera 4 imágenes en resolución $1200 \times 1200\text{ px}$ por cada SKU:
1. **`01_portada_blanca.jpg`**: Primera fotografía oficial recortada al ras y maximizada sobre fondo blanco puro $\text{RGB}(255, 255, 255)$.
2. **`02_angulo_galeria.jpg`**: Segunda fotografía oficial extraída del CDN de Price Shoes (o encuadre de detalle a $0^\circ$ sin rotación artificial).
3. **`03_ficha_beneficios.jpg`**: Infografía de 2 columnas con propuesta de valor y chips azules que muestran las **tallas reales con stock en Vallejo**.
4. **`04_guia_tallas_cm.jpg`**: Guía de medidas y equivalencias en centímetros con resaltado en verde de las tallas disponibles e instrucciones de medición en 3 pasos.

### Clasificador Jerárquico de 12 Perfiles
Para evitar cruces de tablas (por ejemplo, que un calzado marca *24 hrs* o *Capa de Ozono* reciba tabla de ropa), el clasificador evalúa primero sustantivos explícitos de calzado y luego clasifica en:
1. 👟 **Calzado Infantil / Escolar** ($15.0\text{ a }22.5\text{ MX}$)
2. 👞 **Calzado Adulto Dama / Caballero** ($21.5\text{ a }29.0\text{ MX}$)
3. ✨ **Perfumería y Fragancias** ($\text{ML} / \text{FL. OZ.} / \text{EDT-EDP}$)
4. 🍳 **Hogar, Cocina y Blancos** (Diámetros en $\text{CM}$ y medidas de cama)
5. 🧢 **Accesorios, Gorras, Mochilas y Cinturones**
6. 🧦 **Calcetería, Calcetas y Tines**
7. 🩲 **Ropa Interior, Bóxers, Pantis y Fajas**
8. 🧥 **Chamarras, Chalecos, Sudaderas y Abrigador**
9. 👔 **Camisas y Guayaberas**
10. 👚 **Blusas, Tops y Vestidos Dama**
11. 👕 **Playeras, Polos y Pijamas**
12. 👖 **Pantalones, Jeans y Joggers**

---

## 🚀 Guía de Instalación y Uso Rápido

### 1. Preparar el entorno virtual
```powershell
python -m venv venv
.\venv\Scripts\activate
pip install playwright pillow streamlit pandas curl_cffi pymupdf
playwright install chromium
```

### 2. Iniciar sesión de socio (Generar `data/sesion_vallejo.json`)
```powershell
python paso12_login_socio.py
```

### 3. Extraer SKUs de los 44 PDFs y asegurar limpieza de base de datos
```powershell
python paso0_extractor_catalogos_pdf.py
python purgar_fuente_catalogo.py
```

### 4. Ejecutar el barrido del pipeline (Stock + Finanzas + Estudio Fotográfico HD)
Puedes ejecutar cada paso individualmente o en lote:
```powershell
python paso3_recolector_ligero.py
python paso5_motor_financiero.py
python paso6_estudio_fotografico.py
```
O mediante el orquestador continuo:
```powershell
python pipeline_catalogo.py
```

### 5. Abrir el Panel de Control en Streamlit
```powershell
streamlit run paso4_panel_control.py
```

---

## 🛡️ Configuración Recomendada de `.gitignore`

Para mantener el repositorio ágil en GitHub y evitar subir archivos binarios mayores a $50\text{ MB}$ (como los PDFs crudos o la base de datos local), verifica que tu archivo `.gitignore` contenga:

```gitignore
venv/
__pycache__/
.streamlit/
data/zapateria_vallejo.db
data/zapateria_vallejo.db-shm
data/zapateria_vallejo.db-wal
data/catalogos_pdf/
data/catalogo_listo/
data/sesion_vallejo.json
temp_ocr_*.jpg
```